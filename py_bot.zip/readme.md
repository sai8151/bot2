# Install packages

```
pip install Flask
pip install scikit-learn
pip install requests
pip install beautifulsoup4
pip install transformers

```
